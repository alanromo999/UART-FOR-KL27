/*
 * SERVICE.h
 *
 *  Created on: 14 jun. 2020
 *      Author: user
 */

#ifndef SERVICE_LAYER_SERVICE_H_
#define SERVICE_LAYER_SERVICE_H_
#include "MKL27Z644.h"

	typedef unsigned char 		uint_8;
	typedef unsigned short 		uint_16;
	typedef unsigned long 		uint_32;

	typedef signed char   		int_8;
	typedef signed short  		int_16;
	typedef signed long   		int_32;

	#define         SUCCESS		1
	#define          ERROR		0
	#define		UART_BAUDRATE 	9600


#endif /* SERVICE_LAYER_SERVICE_H_ */
