

#include "MKL27Z644.h"
#include "Comunication.h"
#define LONG 5
int main(void) {

	uint_8 VarRec[LONG];

		UART_vfnDriverInit ();
			if(COMM_bfnReceiveMsg (&VarRec[0]))
				while(1){
					COMM_bfnReceiveMsg (&VarRec[0]);
				}
				COMM_bfnSendMsg (&Var[0], LONG);



    return 0 ;
}
