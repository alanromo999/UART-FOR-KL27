/*
 * Comunication.h
 *
 *  Created on: 14 jun. 2020
 *      Author: user
 */

#ifndef HILL_COMUNICATION_H_
#define HILL_COMUNICATION_H_
#include "UART_Drive.h"
void COMM_vfnDriverInit (void);
uint_8 COMM_bfnSendMsg (uint_8 * bpMsgToSend, uint_8 bMsgSize);
uint_8 COMM_bfnReceiveMsg (uint_8 * bpDataRx);


#endif /* HILL_COMUNICATION_H_ */
