/*
 * Comunication.c
 *
 *  Created on: 14 jun. 2020
 *      Author: user
 */

#include "Comunication.h"
#include "MKL27Z644.h"
#define ENTER 13

void COMM_vfnDriverInit (void){
	 UART_vfnDriverInit ();
}
uint_8 COMM_bfnSendMsg (uint_8 * bpMsgToSend, uint_8 bMsgSize){
	uint_8 bStatus=0;
			for(uint_8 i=0;i<bMsgSize; ){
				if(LPUART_STAT_TDRE_MASK & LPUART0->STAT ){//TDRE will set when the transmit data register (LPUART_DATA) is empty
					LPUART0->DATA =*bpMsgToSend;//ASIGN LETTER BY LETTER
					bpMsgToSend++;
					i++;
				}else{
					bStatus=ERROR;
				}

			}
	return bStatus;
	}


uint_8 COMM_bfnReceiveMsg (uint_8 * bpDataRx){
	uint_8 bStatus=0;
	uint_8 bEscape=1;

		while(bEscape){
			if(LPUART_STAT_RDRF_MASK & LPUART0->STAT){// RDRF Receive Data Register Full Flag, THE RECIVE BUFFER IS FULL THE MASK IS 1<<21, ITS TO CHECK IF RDRF ITS ON
				bStatus=SUCCESS;
				*bpDataRx= LPUART0-> DATA;
					if(*bpDataRx=='\r'){
						bEscape=0;
					}
						bpDataRx++;
			}else{
				bStatus=ERROR;
			}
		}

		return bStatus;
	}

