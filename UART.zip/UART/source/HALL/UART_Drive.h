/*
 * INICIA.H
 *
 *  Created on: 14 jun. 2020
 *      Author: user
 */

#ifndef HALL_INICIA_H_
#define HALL_INICIA_H_
#include "SERVICE.h"
void UART_vfnDriverInit (void);
uint_8 UART_bfnRead (uint_8 *bpRxData);
uint_8 UART_bfnSend (uint_8 bTxData);




#endif /* HALL_INICIA_H_ */
