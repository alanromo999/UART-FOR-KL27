/*
 * INICIA.C
 *
 *  Created on: 14 jun. 2020
 *      Author: user
 */
#include "UART_Drive.h"
#include "MKL27Z644.h"


void UART_vfnDriverInit (void){
		MCG -> C1 |= MCG_C1_CLKS(1);//LIRC
		MCG -> C1 |= MCG_C1_IREFSTEN(1);//LIRC ENABLE
		MCG -> C1 |= MCG_C1_IRCLKEN(1);//IRCLKEN
		MCG -> C2 |= MCG_C2_IRCS(1);
		SIM -> SCGC5 |= SIM_SCGC5_PORTA_MASK;
		SIM -> 	SCGC5  |= SIM_SCGC5_LPUART0_MASK;//TURN ON THE LPUART0
		SIM->SOPT2 |= SIM_SOPT2_LPUART0SRC(3);//8M CLOCK, Selects the clock source for the LPUART0 transmit and receive clock.
		LPUART0 -> BAUD |= ((LPUART_BAUD_OSR(31)) | (LPUART_BAUD_SBR(20)) );//8M=CLK, FORMULA OF THE BDR= (CLK/(OSR+1)*26=9615.38, ASK IF THIS IS OK
		PORTA-> PCR[1] |= PORT_PCR_MUX(2);//LPUART_BAUD_SBNSPTA1 RX & PTA2 TX
		PORTA-> PCR[2] |= PORT_PCR_MUX(2);//PTA1 RX & PTA2 TX
		LPUART0-> BAUD |= LPUART_BAUD_SBNS(0); /// BITSTOP
		LPUART0-> BAUD |= LPUART_BAUD_RXEDGIE(1); /// BITSTOPRXEDGIE
		LPUART0 -> STAT |= LPUART_STAT_MSBF(0);//TRANS
		LPUART0-> CTRL |= LPUART_CTRL_RE(1); /// RECEPTOR
		LPUART0 -> CTRL |= LPUART_CTRL_TE(1);//TRANS

}
uint_8 UART_bfnRead (uint_8 *bpRxData){
	uint_8 bStatus=0;

		if(LPUART_STAT_RDRF_MASK & LPUART0->STAT){// RDRF Receive Data Register Full Flag, THE RECIVE BUFFER IS FULL THE MASK IS 1<<21, ITS TO CHECK IF RDRF ITS ON
			bStatus=SUCCESS;
			*bpRxData= LPUART0-> DATA;
		}else{
			bStatus=ERROR;
		}
			return bStatus;
	}


uint_8 UART_bfnSend (uint_8 bTxData){
	uint_8 bStatus=0;


	if(LPUART_STAT_TDRE_MASK & LPUART0->STAT ){//TDRE  will set when the transmit data register (LPUART_DATA) is empty
		bStatus=SUCCESS;
		LPUART0->DATA = bTxData;
	}else{
		bStatus=ERROR;
	}
	return bStatus;
}



